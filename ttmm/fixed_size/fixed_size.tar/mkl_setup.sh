#! /usr/bin/bash

export INTEL_HOME=/s/parsons/l/sys/intel_2018
echo export INTEL_HOME=/s/parsons/l/sys/intel_2018 ; echo export PATH=${PATH}:${INTEL_HOME}/bin ; echo export LD_LIBRARY_PATH=${INTEL_HOME}/mkl/lib/intel64:${INTEL_HOME}/lib/intel64:${LD_LIBRARY_PATH} ; 
