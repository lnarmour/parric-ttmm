float* toBlocks(float *array, int sideLength, int* newSideLength);
void fromBlocks(float *bm, float *normal, int bmsize, int nsize);
